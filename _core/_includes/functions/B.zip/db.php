<?php

$db_con = mysqli_connect($db_host,$db_user,$db_pass,$db_name);
mysqli_set_charset($db_con, "utf8mb4");

?>